# Устранение неполадок расширения

## Проблема: "Ошибка сети" при вводе кода

### ✅ Что было исправлено:

1. **CORS заголовки** - добавлены во все API endpoints
2. **OPTIONS preflight** - добавлена обработка preflight запросов
3. **Логирование** - добавлено для отладки

### 🔍 Как проверить:

#### 1. Проверка в DevTools расширения:

1. Откройте popup расширения
2. Правый клик → "Проверить элемент" (или F12)
3. Перейдите на вкладку **Console**
4. Введите код и нажмите "Привязать"
5. Смотрите ошибки в Console

#### 2. Проверка Network запросов:

1. В DevTools перейдите на вкладку **Network**
2. Введите код
3. Найдите запрос к `/api/extension/verify`
4. Проверьте:
   - **Status**: должен быть 200
   - **Headers**: должны быть CORS заголовки
   - **Response**: должен быть JSON с `success: true`

#### 3. Проверка логов Railway:

После ввода кода должны появиться логи:
```
[EXTENSION API] GET /api/extension/verify - code=...
[EXTENSION API] OPTIONS preflight request for /api/extension/verify
```

Если логов нет - запрос не доходит до сервера.

### 🐛 Возможные проблемы:

#### 1. CORS ошибка в Console:
```
Access to fetch at '...' from origin 'chrome-extension://...' has been blocked by CORS policy
```

**Решение:** Проверьте, что Railway задеплоил последние изменения с CORS заголовками.

#### 2. 404 Not Found:
```
GET https://web-production-3921c.up.railway.app/api/extension/verify?code=... 404
```

**Решение:** Проверьте, что URL правильный и сервер запущен.

#### 3. 500 Internal Server Error:
```
GET ... 500 (Internal Server Error)
```

**Решение:** Проверьте логи Railway - там будет детальная ошибка.

#### 4. Network Error / Failed to fetch:
```
Failed to fetch
NetworkError when attempting to fetch resource
```

**Возможные причины:**
- Сервер не запущен
- Неправильный URL
- Проблемы с сетью
- Блокировка расширением/антивирусом

**Решение:**
1. Проверьте URL в `popup.js`: `https://web-production-3921c.up.railway.app`
2. Проверьте, что сервер доступен: откройте в браузере `https://web-production-3921c.up.railway.app/health`
3. Проверьте логи Railway

### 🧪 Тестирование API напрямую:

#### В консоли браузера (на любой странице):
```javascript
fetch('https://web-production-3921c.up.railway.app/api/extension/verify?code=TEST123')
  .then(r => r.json())
  .then(console.log)
  .catch(console.error)
```

Если видите CORS ошибку - проблема в заголовках (но мы их уже добавили).

#### В консоли расширения (DevTools popup):
```javascript
fetch('https://web-production-3921c.up.railway.app/api/extension/verify?code=YOUR_CODE')
  .then(r => r.json())
  .then(console.log)
  .catch(console.error)
```

### 📋 Чеклист отладки:

- [ ] Railway задеплоил последние изменения
- [ ] URL правильный: `https://web-production-3921c.up.railway.app`
- [ ] Сервер доступен (проверьте `/health`)
- [ ] Таблица `extension_links` создана в БД
- [ ] Код не истек (действует 10 минут)
- [ ] Код не использован ранее
- [ ] В Console нет ошибок JavaScript
- [ ] В Network виден запрос к API
- [ ] В логах Railway видны запросы

### 🔧 Если ничего не помогает:

1. **Перезагрузите расширение:**
   - `chrome://extensions/`
   - Нажмите "Обновить" на расширении

2. **Проверьте версию на Railway:**
   - Убедитесь, что последний коммит задеплоен

3. **Проверьте логи Railway:**
   - Должны быть логи `[EXTENSION API]` при запросах

4. **Проверьте таблицу в БД:**
   ```sql
   SELECT * FROM extension_links WHERE code = 'YOUR_CODE';
   ```
