# Инструкция по развертыванию расширения

## 📦 Zip-файл для Chrome

Файл `moviebot-extension.zip` готов для загрузки в Chrome.

### Установка из zip-файла:

1. Распакуйте `moviebot-extension.zip` в любую папку
2. Откройте Chrome → `chrome://extensions/`
3. Включите "Режим разработчика" (Developer mode)
4. Нажмите "Загрузить распакованное расширение" (Load unpacked)
5. Выберите распакованную папку `moviebot-extension`

## 🔄 GitHub

**ДА, стоит закоммитить расширение в репозиторий проекта.**

Расширение - это часть проекта, его стоит версионировать вместе с ботом.

```bash
cd /Users/nikitazaporohzets/Desktop/Кино/movie_planner_bot
git add moviebot-extension/
git commit -m "Add browser extension for Movie Planner Bot"
git push
```

## 🚂 Railway

### ❌ НЕТ, расширение НЕ нужно размещать на Railway

**Почему:**
- Расширение работает на стороне клиента (в браузере пользователя)
- Это не веб-приложение, которое нужно деплоить на сервер
- API endpoints уже есть в `web_app.py` и работают на Railway

### ✅ Что уже работает на Railway:

1. **API endpoints** (уже в `web_app.py`):
   - `/api/extension/verify` - проверка кода
   - `/api/extension/film-info` - информация о фильме
   - `/api/extension/add-film` - добавление фильма
   - `/api/extension/create-plan` - создание плана

2. **Команда `/code`** в боте (уже в `start.py`)

3. **Таблица `extension_links`** в БД (создается автоматически при инициализации)

### 🔍 Что проверить на Railway:

1. ✅ API endpoints доступны по URL: `https://web-production-3921c.up.railway.app/api/extension/*`
2. ✅ Команда `/code` работает в боте
3. ✅ Таблица `extension_links` создана в БД

**Ничего дополнительно настраивать на Railway не нужно!**

## 📋 Чеклист перед использованием

- [x] API_BASE_URL настроен на Railway URL
- [x] Manifest.json обновлен
- [x] Content scripts настроены
- [x] Иконки созданы
- [x] Zip-файл собран
- [ ] Расширение закоммичено в GitHub (опционально)
- [ ] Расширение установлено в браузер
- [ ] Протестирована авторизация через `/code`
- [ ] Протестирован парсинг фильмов на Letterboxd/IMDb/Кинопоиске

## 🎯 Итого

1. **Zip-файл**: Готов, можно устанавливать
2. **GitHub**: Рекомендуется закоммитить
3. **Railway**: Ничего делать не нужно, всё уже работает
